import type { NextAuthOptions } from 'next-auth';
import DiscordProvider from 'next-auth/providers/discord';
export const authOptions: NextAuthOptions = {
  providers: [DiscordProvider({ clientId: process.env.DISCORD_CLIENT_ID || 'missing-id', clientSecret: process.env.DISCORD_CLIENT_SECRET || 'missing-secret', authorization: { params: { scope: 'identify' } } })],
  session: { strategy: 'jwt' },
  pages: { signIn: '/login' },
  callbacks: {
    async jwt({ token, account, profile }) { if (account?.provider === 'discord' && profile?.id) token.discordId = String(profile.id); return token; },
    async session({ session, token }) { if (session.user) (session.user as typeof session.user & { discordId?: string }).discordId = token.discordId as string | undefined; return session; }
  }
};
