import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const session = await getServerSession(authOptions);
  const discordId = (session?.user as {discordId?: string}|undefined)?.discordId;
  if (!discordId) return NextResponse.json({error:'Unauthorized'}, {status:401});
  const user = await prisma.user.findUnique({where:{discordId}});
  if (!user) return NextResponse.json([]);
  const memberships = await prisma.membership.findMany({where:{userId:user.id},include:{community:true}});
  return NextResponse.json(memberships.map(m=>({ ...m.community, role:m.role })));
}
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const discordId = (session?.user as {discordId?: string}|undefined)?.discordId;
  if (!discordId) return NextResponse.json({error:'Unauthorized'}, {status:401});
  let body: unknown;
  try {body = await req.json();} catch {return NextResponse.json({error:'Invalid JSON'}, {status:400});}
  const input = body as {name?:unknown};
  if (typeof input.name !== 'string' || input.name.trim().length < 3 || input.name.trim().length > 60) return NextResponse.json({error:'Name must be 3–60 characters'}, {status:400});
  const name = input.name.trim();
  const stem = name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40);
  if (!stem) return NextResponse.json({error:'Name must include a letter or number'}, {status:400});
  const user = await prisma.user.upsert({where:{discordId},update:{name: session?.user?.name ?? 'Discord user', avatar: session?.user?.image},create:{discordId,name:session?.user?.name ?? 'Discord user',avatar:session?.user?.image}});
  const slug = `${stem}-${crypto.randomUUID().slice(0,8)}`;
  const community = await prisma.community.create({data:{name,slug,createdById:user.id,members:{create:{userId:user.id,role:'OWNER'}}}});
  return NextResponse.json(community, {status:201});
}
