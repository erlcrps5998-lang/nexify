import type { Metadata } from 'next';
import './styles.css';
export const metadata: Metadata = {title:'Nexify — ER:LC Community Management',description:'Manage your ER:LC communities, staff, moderation and sessions in one place.'};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>}
