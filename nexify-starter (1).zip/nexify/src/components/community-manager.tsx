'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
type Community = {id:string;name:string;slug:string;role:string};
export function CommunityManager({signedIn}:{signedIn:boolean}) {
 const [communities,setCommunities]=useState<Community[]>([]);const [name,setName]=useState('');const [loading,setLoading]=useState(false);const [error,setError]=useState('');
 useEffect(()=>{if(signedIn)fetch('/api/communities').then(r=>r.ok?r.json():[]).then(setCommunities).catch(()=>setError('Database is not configured or available.'));},[signedIn]);
 async function create(){setError('');setLoading(true);try{const res=await fetch('/api/communities',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name})});const result=await res.json();if(!res.ok)throw new Error(result.error||'Could not create community');setCommunities(old=>[...old,{...result,role:'OWNER'}]);setName('');}catch(e){setError(e instanceof Error?e.message:'Unexpected error');}finally{setLoading(false);}}
 if(!signedIn)return <div className="empty"><div className="emptyicon">◈</div><h3>Your communities start here</h3><p>Sign in with Discord to create your first workspace.</p><Link className="primary" href="/login">Connect Discord →</Link></div>;
 return <div className="communityarea">{communities.map(c=><div className="community" key={c.id}><span className="communityavatar">{c.name.slice(0,1)}</span><div><strong>{c.name}</strong><small>{c.slug}</small></div><span className="pill">{c.role}</span></div>)}{!communities.length&&<p className="muted">No communities yet. Create your first below.</p>}<div className="createform"><input aria-label="Community name" placeholder="Your community name" value={name} maxLength={60} onChange={e=>setName(e.target.value)}/><button disabled={loading||name.trim().length<3} onClick={create}>{loading?'Creating…':'+ Create community'}</button></div>{error&&<p className="error" role="alert">{error}</p>}</div>
}
